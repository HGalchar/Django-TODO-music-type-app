
from django.contrib import admin
from django.urls import path,include
from music.views import index,Home,adddata

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home',Home),
    path('', index ),
    path('adddata', adddata),

]
