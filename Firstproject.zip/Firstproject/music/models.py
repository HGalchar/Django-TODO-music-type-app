from django.db import models

# Create your models here.

class MusicItems(models.Model):
    content=models.TextField()
