from django.shortcuts import render,HttpResponse,HttpResponseRedirect
from music.models import MusicItems

# Create your views here.

def Home(request):
    return render(request, 'home.html')

def index(request):
    all_music_items= MusicItems.objects.all()
    return render(request,"musicname.html", {'all_items': all_music_items})


def adddata(request):
    c=request.POST['content']
    new_item=MusicItems(content=c)
    new_item.save()
    return HttpResponseRedirect('/musicname')